export interface Person {
    id: number;
    fname: string;
    lname: string;
}