import { Person } from "../models/Person.model";

export interface AppState {
    people:Person[];
}